using System;

namespace Progression
{
    public abstract class Progression
    {
        public abstract double GetElement(int k);
    }
}
