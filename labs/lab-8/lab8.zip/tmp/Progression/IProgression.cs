using System;

namespace Progression
{
    public interface IProgression
    {
        double GetElement(int k);
    }
}
