using System;

namespace MyClass
{
    public interface IPubs
    {
        void Subs();
        bool IfSubs { get; set; }
    }
}
